# Todo-List---Django
Developed a full-stack to-do list web applica- tion using Django, with features like task man- agement, user authentication, and responsive design. Integrated Django ORM for database  operations. 

![image](https://github.com/user-attachments/assets/6f801ecc-8a14-4c37-aef9-38c376971ea6)
